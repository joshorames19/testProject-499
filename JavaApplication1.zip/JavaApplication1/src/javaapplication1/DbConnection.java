/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;

import java.sql.*;
/**
 * @author Orames
 */
public class DbConnection {
    Connection con=null;
    
    public static Connection ConnectionDB(){
        try{
            Class.forName("org.sqlite.JDBC");
            Connection con = DriverManager.getConnection("jdbc:sqlite:LoginD.db");
            System.out.println("Connected to database!");
            return con;
        }
        catch(Exception e){
            System.out.println("Connection failed! "+ e);
            return null;
        }
    }
}
